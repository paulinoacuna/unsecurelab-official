<?php

/***************************************************************
 * 
 ***************************************************************/

$EM_CONF[$_EXTKEY] = array(
	'title' => 'UN - Plantilla predeterminada',
	'description' => 'Plantilla institucional predeterminada para los sitios web de la Universidad Nacional de Colombia',
	'category' => 'template',
	'author' => 'Oficina de Medios Digitales - Unimedios, Giovanni Romero Pérez',
	'author_email' => 'mediosdigitales@unal.edu.co, gromerop@unal.edu.co',
	'state' => 'stable',
	'internal' => '',
	'uploadfolder' => '0',
	'createDirs' => '',
	'clearCacheOnLoad' => 0,
	'version' => '0.2.0',
	'constraints' => array(
		'depends' => array(
			'typo3' => '6.2',
		),
		'conflicts' => array(
		),
		'suggests' => array(
		),
	),
);
