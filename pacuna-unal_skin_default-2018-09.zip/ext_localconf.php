<?php 

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig('<INCLUDE_TYPOSCRIPT: source="FILE:EXT:unal_skin_default/Configuration/PageTSconfig/lang.tsconfig">');
