# Idioma predeterminado: Español
tx_unalskindefault.parameters {
	breadcrumbPosition=Está en:
	currentLang = es
	
	languageCodes = 0,4,1,3,5,2
	languageId = es || de || en || fr || it || pt
}

	

[globalVar = GP:L = 1]
	tx_unalskindefault.parameters.breadcrumbPosition=You are in:
	tx_unalskindefault.parameters.currentLang = en
[end]
[globalVar = GP:L = 2]
	tx_unalskindefault.parameters.breadcrumbPosition=Você está em:
	tx_unalskindefault.parameters.currentLang = pt
[end]
[globalVar = GP:L = 3]
	tx_unalskindefault.parameters.breadcrumbPosition=Vous êtes dans:
	tx_unalskindefault.parameters.currentLang = fr
[end]
[globalVar = GP:L = 4]
	tx_unalskindefault.parameters.breadcrumbPosition=Sie sind in:
	tx_unalskindefault.parameters.currentLang = de
[end]
[globalVar = GP:L = 5]
	tx_unalskindefault.parameters.breadcrumbPosition=Sei in:
	tx_unalskindefault.parameters.currentLang = it
[end]